setwd("C://Users//CYBORG//Desktop//IT24102753_Lab 9")

# Set seed
set.seed(123)

#  i. Generate a random sample of size 25 for the baking time.
sample_size <- 25
mu <- 45
sigma <- 2
baking_times <- rnorm(sample_size, mean = mu, sd = sigma)
print(baking_times)

#  ii. Test whether the average baking time is less than 46 minutes at a 5% level of significance.
t_test_result <- t.test(baking_times, mu = 46, alternative = "less")
print(t_test_result)